import { useState, useEffect, useMemo } from 'react';
import { Transaction } from '@/types';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { Dashboard } from '@/components/Dashboard';
import { TransactionForm } from '@/components/TransactionForm';
import { TransactionList } from '@/components/TransactionList';
import { Auth } from '@/components/Auth';
import { Button } from '@/components/ui/Button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { Moon, Sun, Download, LogOut, Filter } from 'lucide-react';
import { Select } from '@/components/ui/Select';
import Papa from 'papaparse';
import { format, parseISO, startOfMonth, endOfMonth, isWithinInterval } from 'date-fns';

export default function App() {
  const [transactions, setTransactions] = useLocalStorage<Transaction[]>('transactions', []);
  const [isLocked, setIsLocked] = useLocalStorage<boolean>('isLocked', true);
  const [darkMode, setDarkMode] = useLocalStorage<boolean>('darkMode', false);
  const [filterMonth, setFilterMonth] = useState<string>('all');

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const handleAddTransaction = (transaction: Transaction) => {
    setTransactions((prev) => [transaction, ...prev]);
  };

  const handleDeleteTransaction = (id: string) => {
    setTransactions((prev) => prev.filter((t) => t.id !== id));
  };

  const handleExportCSV = () => {
    const csv = Papa.unparse(transactions);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `transactions_${format(new Date(), 'yyyy-MM-dd')}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filteredTransactions = useMemo(() => {
    if (filterMonth === 'all') return transactions;
    
    const [year, month] = filterMonth.split('-');
    const date = new Date(parseInt(year), parseInt(month) - 1);
    const start = startOfMonth(date);
    const end = endOfMonth(date);

    return transactions.filter((t) => 
      isWithinInterval(parseISO(t.date), { start, end })
    );
  }, [transactions, filterMonth]);

  // Generate month options from transactions
  const monthOptions = useMemo(() => {
    const months = new Set<string>();
    transactions.forEach(t => {
      const date = parseISO(t.date);
      months.add(format(date, 'yyyy-MM'));
    });
    return Array.from(months).sort().reverse();
  }, [transactions]);

  if (isLocked) {
    return <Auth onUnlock={() => setIsLocked(false)} />;
  }

  return (
    <div className="min-h-screen bg-background text-foreground transition-colors duration-300">
      <div className="container mx-auto p-4 max-w-6xl space-y-8">
        {/* Header */}
        <header className="flex flex-col md:flex-row justify-between items-center gap-4 py-6 border-b">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Finance Tracker</h1>
            <p className="text-muted-foreground">
              {format(new Date(), 'EEEE, MMMM do, yyyy')}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="icon"
              onClick={() => setDarkMode(!darkMode)}
              title="Toggle Dark Mode"
            >
              {darkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </Button>
            <Button
              variant="outline"
              onClick={() => setIsLocked(true)}
              title="Lock Dashboard"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Lock
            </Button>
          </div>
        </header>

        {/* Dashboard Stats & Chart */}
        <section>
          <Dashboard transactions={filteredTransactions} filterMonth={filterMonth} />
        </section>

        {/* Main Content Grid */}
        <div className="grid gap-8 md:grid-cols-12">
          {/* Left Column: Add Transaction */}
          <div className="md:col-span-4 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Add New Transaction</CardTitle>
              </CardHeader>
              <CardContent>
                <TransactionForm onAddTransaction={handleAddTransaction} />
              </CardContent>
            </Card>
          </div>

          {/* Right Column: Transaction List */}
          <div className="md:col-span-8 space-y-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
                <CardTitle>Recent Transactions</CardTitle>
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-2">
                    <Filter className="h-4 w-4 text-muted-foreground" />
                    <Select
                      value={filterMonth}
                      onChange={(e) => setFilterMonth(e.target.value)}
                      className="w-[140px] h-8 text-xs"
                    >
                      <option value="all">All Time</option>
                      {monthOptions.map(month => (
                        <option key={month} value={month}>
                          {format(parseISO(`${month}-01`), 'MMMM yyyy')}
                        </option>
                      ))}
                    </Select>
                  </div>
                  <Button variant="outline" size="sm" onClick={handleExportCSV}>
                    <Download className="h-4 w-4 mr-2" />
                    Export CSV
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <TransactionList 
                  transactions={filteredTransactions} 
                  onDeleteTransaction={handleDeleteTransaction} 
                />
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
